local mouse = player:GetMouse()
print(mouse) --nil in server script