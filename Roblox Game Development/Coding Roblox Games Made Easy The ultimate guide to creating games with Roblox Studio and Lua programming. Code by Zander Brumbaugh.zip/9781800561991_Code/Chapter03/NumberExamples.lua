local myNumber = 99
myNumber = myNumber + 1
myNumber = math.pi