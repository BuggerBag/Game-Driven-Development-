local part = Instance.new("Part")
part.BrickColor = BrickColor.new("Cyan")
part.Parent = workspace