local myBool = true
myBool = not myBool
print(myBool) 